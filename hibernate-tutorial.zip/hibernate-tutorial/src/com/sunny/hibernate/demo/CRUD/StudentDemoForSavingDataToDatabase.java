package com.sunny.hibernate.demo.CRUD;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.sunny.hibernate.mapping.entityClass.StudentEntity;

public class StudentDemoForSavingDataToDatabase {
	
	public static void main(String[] args) {
		
		// Create Session Factory
		SessionFactory sessionFactory = new Configuration()
											.configure("hibernate.cfg.xml") // Same as we have in our project, can pass nothing if xml file name is exactly 'hibernate.cfg.xml'
											.addAnnotatedClass(StudentEntity.class)
											.buildSessionFactory();
		
		// Create session
		Session currentSession = sessionFactory.getCurrentSession();
		try {
			// Use session object to save the java object to database
			StudentEntity entity = new StudentEntity("Sunny", "Mittal", "mittalsunny22@gmail.com");
			
			Transaction beginTransaction = currentSession.beginTransaction(); // Start Transaction
			
			currentSession.save(entity); // Save object
			
			beginTransaction.commit();	// commit transaction
			
			System.out.println("\nGetting student with id: " + entity.getId_PK());

		}catch (Exception e) {
			System.err.println(e);
		}
		finally {
			currentSession.close();
			sessionFactory.close();
		}
	}
}